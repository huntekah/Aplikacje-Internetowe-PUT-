package poker.AI.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PokerArtifactApplication {

	public static void main(String[] args) {
		SpringApplication.run(PokerArtifactApplication.class, args);
	}
}
